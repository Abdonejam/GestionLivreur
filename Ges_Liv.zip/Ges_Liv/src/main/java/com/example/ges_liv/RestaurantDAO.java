package com.example.ges_liv;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RestaurantDAO extends BaseDAO <Restaurant>{
    public RestaurantDAO() throws SQLException {
        super();
    }

    @Override
    public void save(Restaurant object) throws SQLException {
        String request = "insert into restaurant (Nom,Addresse) values (?,?)";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2, object.getAddresse());
        this.preparedStatement.execute();
    }
    @Override
    public void update(Restaurant object) throws SQLException {
        String request = "UPDATE restaurant SET Nom=?,Addresse=? WHERE ID_Restaurant=?";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2, object.getAddresse());
        this.preparedStatement.setLong(3, object.getID_Restaurant());
        this.preparedStatement.execute();

    }

    @Override
    public void delete(Restaurant object) throws SQLException {
        String request = "DELETE FROM restaurant WHERE ID_Restaurant=?";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , object.getID_Restaurant());
        this.preparedStatement.execute();
    }

    @Override
    public List<Restaurant> getAll()  throws SQLException {

        List<Restaurant> mylist = new ArrayList<Restaurant>();

        String request = "select * from restaurant ";
        this.statement = this.connection.createStatement();
        this.resultSet = this.statement.executeQuery(request);
        while (this.resultSet.next()){
            mylist.add(new Restaurant(this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3)));
        }
        return mylist;
    }
    @Override
    public Restaurant getOne (long id) throws SQLException {
        String request = "select * from restaurant where ID_Restaurant=? ";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , id);
        this.preparedStatement.execute();
        Restaurant temp = new Restaurant(this.resultSet.getLong(1),
                this.resultSet.getString(2),
                this.resultSet.getString(3));
        return temp;
    }
}
