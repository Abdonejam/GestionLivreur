package com.example.ges_liv;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Restaurant_Control implements Initializable {
    ObservableList<Restaurant> Res_List = FXCollections.observableArrayList();
    protected static long Temp_ID;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button But_Upd;
    @FXML
    private Button But_Sav;
    @FXML
    private TextField F_Nom ;
    @FXML
    private TextField F_Add ;
    @FXML
    private TableView<Restaurant> Tab_Res;
    @FXML
    private TableColumn<Restaurant,Long> ID;
    @FXML
    private TableColumn<Restaurant,String> Nom;
    @FXML
    private TableColumn<Restaurant,String> Addresse;

    public Restaurant_Control() {
    }
    @FXML
    protected void onSaveButtonClick() {
        try {
            RestaurantDAO restaurantDAO = new RestaurantDAO();
            Restaurant res = new Restaurant(0l ,F_Nom.getText(),F_Add.getText());
            restaurantDAO.save(res);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void UpdateTable() {
        ID.setCellValueFactory(new PropertyValueFactory("ID_Restaurant"));
        Nom.setCellValueFactory(new PropertyValueFactory("Nom"));
        Addresse.setCellValueFactory(new PropertyValueFactory("Addresse"));
        Tab_Res.setItems(getData());
        But_Upd.setDisable(true);
        But_Sav.setDisable(false);
        if(Tab_Res.getColumns().size()<5){
            addModifyToTable();
            addDeleteToTable();
        }}

    public static ObservableList<Restaurant> getData() {
        RestaurantDAO restaurantDAO = null;
        ObservableList<Restaurant> listfx = FXCollections.observableArrayList();

        try {
            restaurantDAO = new RestaurantDAO();
            listfx.addAll(restaurantDAO.getAll());
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.UpdateTable();
    }

    private void addModifyToTable() {
        TableColumn<Restaurant, Void> colBtn = new TableColumn("Button Column");
        colBtn.setText("Modifier");
        Callback<TableColumn<Restaurant, Void>, TableCell<Restaurant, Void>> cellFactory = new Callback<TableColumn<Restaurant, Void>, TableCell<Restaurant, Void>>() {
            @Override
            public TableCell<Restaurant, Void> call(final TableColumn<Restaurant, Void> param) {
                final TableCell<Restaurant, Void> cell = new TableCell<Restaurant, Void>() {
                    private final Button btn = new Button("Modifier");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Restaurant data = getTableView().getItems().get(getIndex());
                            try {
                                RestaurantDAO restaurantDAO = new RestaurantDAO();
                                F_Nom.setText(data.getNom());
                                F_Add.setText(data.getAddresse());
                                But_Upd.setDisable(false);
                                But_Sav.setDisable(true);
                                Temp_ID = data.getID_Restaurant();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        Tab_Res.getColumns().add(colBtn);
    }

    private void addDeleteToTable() {
        TableColumn<Restaurant, Void> colBtn2 = new TableColumn("Button Column");
        colBtn2.setText("Supprimer");
        Callback<TableColumn<Restaurant, Void>, TableCell<Restaurant, Void>> cellFactory = new Callback<TableColumn<Restaurant, Void>, TableCell<Restaurant, Void>>() {
            @Override
            public TableCell<Restaurant, Void> call(final TableColumn<Restaurant, Void> param) {
                final TableCell<Restaurant, Void> cell = new TableCell<Restaurant, Void>() {
                    private final Button btn = new Button("Supprimer");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Restaurant data = getTableView().getItems().get(getIndex());
                            System.out.println("selectedData:" + data);
                            try {
                                RestaurantDAO restaurantDAO = new RestaurantDAO();
                                restaurantDAO.delete(data);
                                UpdateTable();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn2.setCellFactory(cellFactory);
        Tab_Res.getColumns().add(colBtn2);
    }

    public void onUpdateButtonClick(ActionEvent actionEvent) {
        try {
            RestaurantDAO restaurantDAO = new RestaurantDAO();
            Restaurant res = new Restaurant(Temp_ID ,F_Nom.getText(),F_Add.getText());
            restaurantDAO.update(res);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void SwitchCom(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Commande.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchClt(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Client.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchLiv(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Livreur.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }
}
