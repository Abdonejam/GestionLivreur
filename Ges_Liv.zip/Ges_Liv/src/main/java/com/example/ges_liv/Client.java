package com.example.ges_liv;

public class Client {
    private long ID_Client;
    private String Nom;
    private String Prenom;
    private String Email;
    private String Telephone;
    private String Addresse;

    public Client(long I, String N, String P, String E, String T, String A) {
        this.ID_Client= I;
        this.Nom = N;
        this.Prenom= P;
        this.Email = E;
        this.Telephone = T;
        this.Addresse = A;
    }


    public long getID_Client() {
        return ID_Client;
    }

    public void setID_Client(long ID_Client) {
        this.ID_Client = ID_Client;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public void setPrenom(String prenom) {
        Prenom = prenom;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getTelephone() {
        return Telephone;
    }

    public void setTelephone(String telephone) {
        Telephone = telephone;
    }

    public String getAddresse() {
        return Addresse;
    }

    public void setAddresse(String addresse) {
        Addresse = addresse;
    }

    @Override
    public String toString() {
        return "Client{" +
                "ID_Client=" + ID_Client +
                ", Nom='" + Nom + '\'' +
                ", Prenom='" + Prenom + '\'' +
                ", Email='" + Email + '\'' +
                ", Addresse='" + Addresse + '\'' +
                '}';
    }
}
