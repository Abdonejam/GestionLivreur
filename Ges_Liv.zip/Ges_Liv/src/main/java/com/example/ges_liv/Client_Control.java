package com.example.ges_liv;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Client_Control implements Initializable {
    protected static long Temp_ID;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button But_Upd;
    @FXML
    private Button But_Sav;
    @FXML
    private TextField F_Nom ;
    @FXML
    private TextField F_Pre ;
    @FXML
    private TextField F_Email ;
    @FXML
    private TextField F_Tel ;
    @FXML
    private TextField F_Add ;
    @FXML
    private TableView<Client> Tab_Clt;
    @FXML
    private TableColumn<Client,Long> ID;
    @FXML
    private TableColumn<Client,String> Nom;
    @FXML
    private TableColumn<Client,String> Pre;
    @FXML
    private TableColumn<Client,String> Email;
    @FXML
    private TableColumn<Client,String> Tel;
    @FXML
    private TableColumn<Client, String> Add;
    public Client_Control() {
    }
    @FXML
    protected void onSaveButtonClick() {
        try {
            ClientDAO clientDAO = new ClientDAO();
            Client clt = new Client(0l ,F_Nom.getText(),F_Pre.getText(),F_Email.getText(),F_Tel.getText(),F_Add.getText());
            clientDAO.save(clt);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void UpdateTable() {
        ID.setCellValueFactory(new PropertyValueFactory("ID_Client"));
        Nom.setCellValueFactory(new PropertyValueFactory("Nom"));
        Pre.setCellValueFactory(new PropertyValueFactory("Prenom"));
        Email.setCellValueFactory(new PropertyValueFactory("Email"));
        Tel.setCellValueFactory(new PropertyValueFactory("Telephone"));
        Add.setCellValueFactory(new PropertyValueFactory("Addresse"));
        Tab_Clt.setItems(getData());
        But_Upd.setDisable(true);
        But_Sav.setDisable(false);
        if(Tab_Clt.getColumns().size()<8){
            addModifyToTable();
            addDeleteToTable();
        }}

    public static ObservableList<Client> getData() {
        ClientDAO clientDAO = null;
        ObservableList<Client> listfx = FXCollections.observableArrayList();

        try {
            clientDAO = new ClientDAO();
            listfx.addAll(clientDAO.getAll());
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.UpdateTable();
    }

    private void addModifyToTable() {
        TableColumn<Client, Void> colBtn = new TableColumn("Button Column");
        colBtn.setText("Modifier");
        Callback<TableColumn<Client, Void>, TableCell<Client, Void>> cellFactory = new Callback<TableColumn<Client, Void>, TableCell<Client, Void>>() {
            @Override
            public TableCell<Client, Void> call(final TableColumn<Client, Void> param) {
                final TableCell<Client, Void> cell = new TableCell<Client, Void>() {
                    private final Button btn = new Button("Modifier");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Client data = getTableView().getItems().get(getIndex());
                            try {
                                ClientDAO clientDAO = new ClientDAO();
                                F_Nom.setText(data.getNom());
                                F_Pre.setText(data.getPrenom());
                                F_Email.setText(data.getEmail());
                                F_Tel.setText(data.getTelephone());
                                F_Add.setText(data.getAddresse());
                                But_Upd.setDisable(false);
                                But_Sav.setDisable(true);
                                Temp_ID = data.getID_Client();

                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        Tab_Clt.getColumns().add(colBtn);
    }

    private void addDeleteToTable() {
        TableColumn<Client, Void> colBtn2 = new TableColumn("Button Column");
        colBtn2.setText("Supprimer");
        Callback<TableColumn<Client, Void>, TableCell<Client, Void>> cellFactory = new Callback<TableColumn<Client, Void>, TableCell<Client, Void>>() {
            @Override
            public TableCell<Client, Void> call(final TableColumn<Client, Void> param) {
                final TableCell<Client, Void> cell = new TableCell<Client, Void>() {
                    private final Button btn = new Button("Supprimer");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Client data = getTableView().getItems().get(getIndex());
                            System.out.println("selectedData:" + data);
                            try {
                                ClientDAO clientDAO = new ClientDAO();
                                clientDAO.delete(data);
                                UpdateTable();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn2.setCellFactory(cellFactory);
        Tab_Clt.getColumns().add(colBtn2);
    }

    public void onUpdateButtonClick(ActionEvent actionEvent) {
        try {
            ClientDAO clientDAO = new ClientDAO();
            Client clt = new Client(Temp_ID ,F_Nom.getText(),F_Pre.getText(),F_Email.getText(),F_Tel.getText(),F_Add.getText());
            clientDAO.update(clt);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void SwitchCom(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Commande.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchRes(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Restaurant.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchLiv(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Livreur.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }
}
