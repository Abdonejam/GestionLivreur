package com.example.ges_liv;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.PrimitiveIterator;

public class Commande {
    private long ID_Commande;
    private String Prix;
    private String statut;
    private String Date_Commande;
    private String Addresse_Livraison;
    private String Details_Commande;

    public Commande(long I, String P, String S, String D, String A, String E) {
        this.ID_Commande = I;
        this.Prix = P;
        this.statut = S;
        this.Date_Commande = D;
        this.Addresse_Livraison = A;
        this.Details_Commande = E;
    }

    public long getID_Commande() {
        return ID_Commande;
    }

    public void setID_Commande(long ID_Commande) {
        this.ID_Commande = ID_Commande;
    }

    public String getPrix() {
        return Prix;
    }

    public void setPrix(String prix) {
        Prix = prix;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getDate_Commande() {
        return Date_Commande;
    }

    public void setDate_Commande(String date_Commande) {
        Date_Commande = date_Commande;
    }

    public String getAddresse_Livraison() {
        return Addresse_Livraison;
    }

    public void setAddresse_Livraison(String addresse_Livraison) {
        Addresse_Livraison = addresse_Livraison;
    }

    public String getDetails_Commande() {
        return Details_Commande;
    }

    public void setDetails_Commande(String details_Commande) {
        Details_Commande = details_Commande;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "ID_Commande=" + ID_Commande +
                ", Prix=" + Prix +
                ", statut='" + statut + '\'' +
                ", Date_Commande=" + Date_Commande +
                ", Addresse_Livraison='" + Addresse_Livraison + '\'' +
                ", Details_Commande='" + Details_Commande + '\'' +
                '}';
    }
}
