package com.example.ges_liv;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class CommandeDAO extends BaseDAO<Commande> {
    public CommandeDAO() throws SQLException{
        super();
    }

    @Override
    public void save(Commande object) throws SQLException {
        String request = "insert into commande (Prix, Statut, Date_Commande, Addresse_Livraison, Details_Commande) values (?,?,?,?,?)";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getPrix());
        this.preparedStatement.setString(2, object.getStatut());
        this.preparedStatement.setString(3 , object.getDate_Commande());
        this.preparedStatement.setString(4 , object.getAddresse_Livraison());
        this.preparedStatement.setString(5 , object.getDetails_Commande());
        this.preparedStatement.execute();
    }
    @Override
    public void update(Commande object) throws SQLException {
        String request = "UPDATE commande SET Prix=?, Statut=?, Date_Commande=?, Addresse_Livraison=?, Details_Commande=? WHERE ID_Commande=?";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getPrix());
        this.preparedStatement.setString(2, object.getStatut());
        this.preparedStatement.setString(3 , object.getDate_Commande());
        this.preparedStatement.setString(4 , object.getAddresse_Livraison());
        this.preparedStatement.setString(5 , object.getDetails_Commande());
        this.preparedStatement.setLong(6 , object.getID_Commande());
        this.preparedStatement.execute();

    }

    @Override
    public void delete(Commande object) throws SQLException {
        String request = "DELETE FROM commande WHERE ID_Commande=?";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , object.getID_Commande());
        this.preparedStatement.execute();
    }

    @Override
    public List<Commande> getAll()  throws SQLException {

        List<Commande> mylist = new ArrayList<Commande>();

        String request = "select * from commande ";
        this.statement = this.connection.createStatement();
        this.resultSet = this.statement.executeQuery(request);
        while (this.resultSet.next()){
            mylist.add(new Commande(this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3),
                    this.resultSet.getString(4),
                    this.resultSet.getString(5),
                    this.resultSet.getString(6)));
        }
        return mylist;
    }
    @Override
    public Commande getOne (long id) throws SQLException {
        String request = "select * from command where ID_Commande=? ";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , id);
        this.preparedStatement.execute();
        Commande temp = new Commande(this.resultSet.getLong(1),
                this.resultSet.getString(2),
                this.resultSet.getString(3),
                this.resultSet.getString(4),
                this.resultSet.getString(5),
                this.resultSet.getString(6));
        return temp;
    }
}

