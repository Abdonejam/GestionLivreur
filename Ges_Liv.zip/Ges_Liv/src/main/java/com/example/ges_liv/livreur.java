package com.example.ges_liv;

public class livreur {
    private long ID_Liv;
    private String Nom_Liv;
    private String Prenom_Liv;
    private String Telephone;
    private String Matricule;

    public livreur(long I, String N, String P, String T, String M) {
        this.ID_Liv = I;
        this.Nom_Liv = N;
        this.Prenom_Liv = P;
        this.Telephone = T;
        this.Matricule = M;
    }

    public long getID_Liv() {
        return ID_Liv;
    }

    public void setID_Liv(long ID_Liv) {
        this.ID_Liv = ID_Liv;
    }

    public String getNom_Liv() {
        return Nom_Liv;
    }

    public void setNom_Liv(String nom_Liv) {
        Nom_Liv = nom_Liv;
    }

    public String getPrenom_Liv() {
        return Prenom_Liv;
    }
    public void setPrenom_Liv(String prenom_Liv) {
        Prenom_Liv = prenom_Liv;
    }

    public String getMatricule() {
        return Matricule;
    }

    public void setMatricule(String matricule) {
        Matricule = matricule;
    }

    public String getTelephone() {
        return Telephone;
    }
    public void setTelephone(String telephone) {
        Telephone = telephone;
    }

    @Override
    public String toString() {
        return "livreur{" +
                "ID_Liv=" + ID_Liv +
                ", Nom_Liv='" + Nom_Liv + '\'' +
                ", Prenom_Liv='" + Prenom_Liv + '\'' +
                ", Telephone='" + Telephone + '\'' +
                ", Matricule='" + Matricule + '\'' +
                '}';
    }
}
