package com.example.ges_liv;

public class Restaurant {
    private long ID_Restaurant;
    private String Nom;
    private String Addresse;
    public Restaurant(long I, String N, String A) {
        this.ID_Restaurant = I;
        this.Nom = N;
        this.Addresse = A;
    }

    public long getID_Restaurant() {
        return ID_Restaurant;
    }

    public void setID_Restaurant(long ID_Restaurant) {
        this.ID_Restaurant = ID_Restaurant;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public String getAddresse() {
        return Addresse;
    }

    public void setAddresse(String addresse_Restaurant) {
        Addresse = addresse_Restaurant;
    }


    @Override
    public String toString() {
        return "Restaurant{" +
                "ID_Restaurant=" + ID_Restaurant +
                ", Nom_Restaurant='" + Nom + '\'' +
                ", Addresse_Restaurant='" + Addresse + '\'' +
                '}';
    }
}
