package com.example.ges_liv;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.net.URL;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.ResourceBundle;

public class Commande_Control implements Initializable {

    ObservableList<Commande> Cmd_List = FXCollections.observableArrayList();
    protected static long Temp_ID;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button But_Upd;
    @FXML
    private Button But_Sav;
    @FXML
    private TextField F_Prix ;
    @FXML
    private TextField F_Statut ;
    @FXML
    private TextField F_Date ;
    @FXML
    private TextField F_Add;
    @FXML
    private TextField F_Details;
    @FXML
    private TableView<Commande> Tab_Com;
    @FXML
    private TableColumn<Commande,Long> ID;
    @FXML
    private TableColumn<Commande,String> Prix;
    @FXML
    private TableColumn<Commande,String> Statut;
    @FXML
    private TableColumn<Commande,String> Date;
    @FXML
    private TableColumn<Commande,String> Addresse;
    @FXML
    private TableColumn<Commande,String> Details;

    public Commande_Control() {
    }
    @FXML
    protected void onSaveButtonClick() {
        try {
            CommandeDAO commandeDAO = new CommandeDAO();
            Commande cmd = new Commande(0L,F_Prix.getText(),F_Statut.getText(),F_Date.getText(),F_Add.getText(),F_Details.getText());
            commandeDAO.save(cmd);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void UpdateTable() {
        ID.setCellValueFactory(new PropertyValueFactory("ID_Commande"));
        Prix.setCellValueFactory(new PropertyValueFactory("Prix"));
        Statut.setCellValueFactory(new PropertyValueFactory("Statut"));
        Date.setCellValueFactory(new PropertyValueFactory("Date_Commande"));
        Addresse.setCellValueFactory(new PropertyValueFactory("Addresse_Livraison"));
        Details.setCellValueFactory(new PropertyValueFactory("Details_Commande"));
        Tab_Com.setItems(getData());
        But_Upd.setDisable(true);
        But_Sav.setDisable(false);
        if(Tab_Com.getColumns().size()<8){
            addModifyToTable();
            addDeleteToTable();
        }}

    public static ObservableList<Commande> getData() {
        CommandeDAO commandeDAO = null;
        ObservableList<Commande> listfx = FXCollections.observableArrayList();
        try {
            commandeDAO = new CommandeDAO();
            listfx.addAll(commandeDAO.getAll());
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UpdateTable();
    }

    private void addModifyToTable() {
        TableColumn<Commande, Void> colBtn = new TableColumn("Button Column");
        colBtn.setText("Action");
        Callback<TableColumn<Commande, Void>, TableCell<Commande, Void>> cellFactory = new Callback<TableColumn<Commande, Void>, TableCell<Commande, Void>>() {
            @Override
            public TableCell<Commande, Void> call(final TableColumn<Commande, Void> param) {
                final TableCell<Commande, Void> cell = new TableCell<Commande, Void>() {
                    private final Button btn = new Button("Modifier");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Commande data = getTableView().getItems().get(getIndex());
                            try {
                                CommandeDAO commandeDAO = new CommandeDAO();
                                F_Prix.setText(data.getPrix());
                                F_Statut.setText(data.getStatut());
                                F_Date.setText(data.getDate_Commande());
                                F_Add.setText(data.getAddresse_Livraison());
                                F_Details.setText(data.getDetails_Commande());
                                But_Upd.setDisable(false);
                                But_Sav.setDisable(true);
                                Temp_ID = data.getID_Commande();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        Tab_Com.getColumns().add(colBtn);
    }

    private void addDeleteToTable() {
        TableColumn<Commande, Void> colBtn2 = new TableColumn("Button Column");
        colBtn2.setText("Supprimer");
        Callback<TableColumn<Commande, Void>, TableCell<Commande, Void>> cellFactory = new Callback<TableColumn<Commande, Void>, TableCell<Commande, Void>>() {
            @Override
            public TableCell<Commande, Void> call(final TableColumn<Commande, Void> param) {
                final TableCell<Commande, Void> cell = new TableCell<Commande, Void>() {
                    private final Button btn = new Button("Supprimer");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            Commande data = getTableView().getItems().get(getIndex());
                            System.out.println("selectedData:" + data);
                            try {
                                CommandeDAO commandeDAO = new CommandeDAO();
                                commandeDAO.delete(data);
                                UpdateTable();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn2.setCellFactory(cellFactory);
        Tab_Com.getColumns().add(colBtn2);
    }

    public void onUpdateButtonClick(ActionEvent actionEvent) {
        try {
            CommandeDAO commandeDAO = new CommandeDAO();
            Commande cmd = new Commande(Temp_ID,F_Prix.getText(),F_Statut.getText(),F_Date.getText(),F_Add.getText(),F_Details.getText());
            commandeDAO.update(cmd);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void SwitchLiv(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Livreur.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchClt(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Client.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchRes(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Restaurant.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }
}
