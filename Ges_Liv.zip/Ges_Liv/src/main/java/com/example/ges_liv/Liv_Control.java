package com.example.ges_liv;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Liv_Control implements Initializable {
    ObservableList<livreur> Liv_List = FXCollections.observableArrayList();
    protected static long Temp_ID;
    @FXML
    private AnchorPane rootPane;
    @FXML
    private Button But_Upd;
    @FXML
    private Button But_Sav;
    @FXML
    private TextField F_Nom ;
    @FXML
    private TextField F_Pre ;
    @FXML
    private TextField F_Tel ;
    @FXML
    private TextField F_Mat ;
    @FXML
    private TableView<livreur> Tab_Liv;
    @FXML
    private TableColumn<livreur,Long> ID;
    @FXML
    private TableColumn<livreur,String> Nom;
    @FXML
    private TableColumn<livreur,String> Pre;
    @FXML
    private TableColumn<livreur,String> Tel ;
    @FXML
    private TableColumn<livreur, String> Mat;

    public Liv_Control() {
    }
    @FXML
    protected void onSaveButtonClick() {
        try {
            LivreurDAO livreurDAO = new LivreurDAO();
            livreur liv = new livreur(0l ,F_Nom.getText(),F_Pre.getText(),F_Tel.getText(),F_Mat.getText());
            livreurDAO.save(liv);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void UpdateTable() {
        ID.setCellValueFactory(new PropertyValueFactory("ID_Liv"));
        Nom.setCellValueFactory(new PropertyValueFactory("Nom_Liv"));
        Pre.setCellValueFactory(new PropertyValueFactory("Prenom_Liv"));
        Tel.setCellValueFactory(new PropertyValueFactory("Telephone"));
        Mat.setCellValueFactory(new PropertyValueFactory("Matricule"));
        Tab_Liv.setItems(getData());
        But_Upd.setDisable(true);
        But_Sav.setDisable(false);
        if(Tab_Liv.getColumns().size()<7){
        addModifyToTable();
        addDeleteToTable();
    }}

    public static ObservableList<livreur> getData() {
        LivreurDAO livreurDAO = null;
        ObservableList<livreur> listfx = FXCollections.observableArrayList();

        try {
            livreurDAO = new LivreurDAO();
            listfx.addAll(livreurDAO.getAll());
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.UpdateTable();
    }

    private void addModifyToTable() {
        TableColumn<livreur, Void> colBtn = new TableColumn("Button Column");
        colBtn.setText("Modifier");
        Callback<TableColumn<livreur, Void>, TableCell<livreur, Void>> cellFactory = new Callback<TableColumn<livreur, Void>, TableCell<livreur, Void>>() {
            @Override
            public TableCell<livreur, Void> call(final TableColumn<livreur, Void> param) {
                final TableCell<livreur, Void> cell = new TableCell<livreur, Void>() {
                    private final Button btn = new Button("Modifier");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            livreur data = getTableView().getItems().get(getIndex());
                            try {
                                LivreurDAO livreurDAO = new LivreurDAO();
                                F_Nom.setText(data.getNom_Liv());
                                F_Pre.setText(data.getPrenom_Liv());
                                F_Tel.setText(data.getTelephone());
                                F_Mat.setText(data.getMatricule());
                                But_Upd.setDisable(false);
                                But_Sav.setDisable(true);
                                Temp_ID = data.getID_Liv();

                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
        Tab_Liv.getColumns().add(colBtn);
    }

    private void addDeleteToTable() {
        TableColumn<livreur, Void> colBtn2 = new TableColumn("Button Column");
        colBtn2.setText("Supprimer");
        Callback<TableColumn<livreur, Void>, TableCell<livreur, Void>> cellFactory = new Callback<TableColumn<livreur, Void>, TableCell<livreur, Void>>() {
            @Override
            public TableCell<livreur, Void> call(final TableColumn<livreur, Void> param) {
                final TableCell<livreur, Void> cell = new TableCell<livreur, Void>() {
                    private final Button btn = new Button("Supprimer");
                    {
                        btn.setOnAction((ActionEvent event) -> {
                            livreur data = getTableView().getItems().get(getIndex());
                            System.out.println("selectedData:" + data);
                            try {
                                LivreurDAO livreurDAO = new LivreurDAO();
                                livreurDAO.delete(data);
                                UpdateTable();
                            } catch (SQLException e) {
                                throw new RuntimeException(e);
                            }
                        });
                    }
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn2.setCellFactory(cellFactory);
        Tab_Liv.getColumns().add(colBtn2);
    }

    public void onUpdateButtonClick(ActionEvent actionEvent) {
        try {
            LivreurDAO livreurDAO = new LivreurDAO();
            livreur liv = new livreur(Temp_ID ,F_Nom.getText(),F_Pre.getText(),F_Tel.getText(),F_Mat.getText());
            livreurDAO.update(liv);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void SwitchCom(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Commande.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
        }

    public void SwitchRes(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Restaurant.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }

    public void SwitchClt(ActionEvent actionEvent) throws IOException {
        URL url = new File("src/main/resources/com/example/ges_liv/Client.fxml").toURI().toURL();
        AnchorPane Commandepane = FXMLLoader.load(url);
        rootPane.getChildren().setAll(Commandepane);
    }
}
