package com.example.ges_liv;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class ClientDAO extends BaseDAO<Client>{
    public ClientDAO() throws SQLException{
        super();
    }

    @Override
    public void save(Client object) throws SQLException {
        String request = "insert into client (Nom,Prenom,Email,Telephone,Addresse) values (?,?,?,?,?)";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2, object.getPrenom());
        this.preparedStatement.setString(3 , object.getEmail());
        this.preparedStatement.setString(4 , object.getTelephone());
        this.preparedStatement.setString(5 , object.getAddresse());
        this.preparedStatement.execute();
    }
    @Override
    public void update(Client object) throws SQLException {
        String request = "UPDATE client SET Nom=?,Prenom=?,Email=?,Telephone=?,Addresse=? WHERE ID_Client=?";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2, object.getPrenom());
        this.preparedStatement.setString(3 , object.getEmail());
        this.preparedStatement.setString(4 , object.getTelephone());
        this.preparedStatement.setString(5 , object.getAddresse());
        this.preparedStatement.setLong(6, object.getID_Client());
        this.preparedStatement.execute();

    }

    @Override
    public void delete(Client object) throws SQLException {
        String request = "DELETE FROM client WHERE ID_Client=?";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , object.getID_Client());
        this.preparedStatement.execute();
    }

    @Override
    public List<Client> getAll()  throws SQLException {

        List<Client> mylist = new ArrayList<Client>();

        String request = "select * from client ";
        this.statement = this.connection.createStatement();
        this.resultSet = this.statement.executeQuery(request);
        while (this.resultSet.next()){
            mylist.add(new Client(this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3),
                    this.resultSet.getString(4),
                    this.resultSet.getString(5),
                    this.resultSet.getString(6)));
        }
        return mylist;
    }
    @Override
    public Client getOne (long id) throws SQLException {
        String request = "select * from client where ID_Client=? ";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , id);
        this.preparedStatement.execute();
        Client temp = new Client(this.resultSet.getLong(1),
                this.resultSet.getString(2),
                this.resultSet.getString(3),
                this.resultSet.getString(4),
                this.resultSet.getString(5),
                this.resultSet.getString(6));
        return temp;
    }
}
