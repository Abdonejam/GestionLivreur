package com.example.ges_liv;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class LivreurDAO extends BaseDAO<livreur> {
    public LivreurDAO() throws SQLException{
        super();
    }

    @Override
    public void save(livreur object) throws SQLException {
        String request = "insert into livreur (Nom_Liv,Prenom_Liv,Telephone,Matricule) values (?,?,?,?)";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom_Liv());
        this.preparedStatement.setString(2, object.getPrenom_Liv());
        this.preparedStatement.setString(3 , object.getTelephone());
        this.preparedStatement.setString(4 , object.getMatricule());
        this.preparedStatement.execute();
    }
    @Override
    public void update(livreur object) throws SQLException {
        String request = "UPDATE livreur SET Nom_Liv=?,Prenom_Liv=?,Telephone=?,Matricule=? WHERE ID_Liv=?";

        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setString(1 , object.getNom_Liv());
        this.preparedStatement.setString(2, object.getPrenom_Liv());
        this.preparedStatement.setString(3 , object.getTelephone());
        this.preparedStatement.setString(4 , object.getMatricule());
        this.preparedStatement.setLong(5 , object.getID_Liv());
        this.preparedStatement.execute();

    }

    @Override
    public void delete(livreur object) throws SQLException {
        String request = "DELETE FROM livreur WHERE ID_Liv=?";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , object.getID_Liv());
        this.preparedStatement.execute();
    }

    @Override
    public List<livreur> getAll()  throws SQLException {

        List<livreur> mylist = new ArrayList<livreur>();

        String request = "select * from livreur";
        this.statement = this.connection.createStatement();
        this.resultSet = this.statement.executeQuery(request);
        while (this.resultSet.next()){
            mylist.add(new livreur(this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3),
                    this.resultSet.getString(4),
                    this.resultSet.getString(5)));
        }
        return mylist;
    }
    @Override
    public livreur getOne (long id) throws SQLException {
        String request = "select * from livreur where ID_Liv=? ";
        this.preparedStatement = this.connection.prepareStatement(request);
        this.preparedStatement.setLong(1 , id);
        this.preparedStatement.execute();
        livreur temp = new livreur(this.resultSet.getLong(1),
                this.resultSet.getString(2),
                this.resultSet.getString(3),
                this.resultSet.getString(4),
                this.resultSet.getString(5));
        return temp;
    }
}

